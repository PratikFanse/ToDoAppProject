package com.app.toDoApp.admin;

import com.app.toDoApp.ToDoAppApplication;
import com.app.toDoApp.auth.dao.UserDao;
import com.app.toDoApp.auth.model.DAOUser;
import com.app.toDoApp.auth.model.UserDTO;
import com.app.toDoApp.userInfo.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
@Service
public class AdminService {
    @Autowired
    private UserDao userDao;

    public List<UserInfo> getAllUser(){
        DAOUser user=userDao.findByUsername(ToDoAppApplication.reqUser);
        System.out.println(user.getUsername());
        List<UserInfo> users = new ArrayList<>();
        if(user.getRole().equals("admin")){
            for(DAOUser u:  userDao.findAll()){

                if(u.getRole().equals("user")){
                users.add(new UserInfo(u.getId(),u.getName(),u.getUsername(),u.getAccstatus(),u.getEmailstatus(),u.getRole()));
            }
            }
        }
        return users;
    }

    public List<UserInfo> updateUser(UserInfo userInfo){

        DAOUser user=userDao.findByUsername(userInfo.getUsername());
        user.setAccstatus(!user.getAccstatus());
        userDao.save(user);
        List<UserInfo> users = new ArrayList<>();
            for(DAOUser u:  userDao.findAll()){
                if(u.getRole().equals("user")){
                users.add(new UserInfo(u.getId(),u.getName(),u.getUsername(),u.getAccstatus(),u.getEmailstatus(),u.getRole()));
                System.out.println(u.getUsername());}
            }
        return users;
    }

}
